public interface FriendEncoder {
  byte[] encode(Friend friend) throws Exception;
}
